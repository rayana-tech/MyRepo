package com.lnk.marts.domain;

// shows the record status whether active or deleted.
public enum RecordStatus {

    active,deleted;
}