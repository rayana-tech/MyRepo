package com.lnk.marts.service;

import org.springframework.data.repository.CrudRepository;

import com.lnk.marts.domain.Order;

public class OrderService  {
	
	
	

}


