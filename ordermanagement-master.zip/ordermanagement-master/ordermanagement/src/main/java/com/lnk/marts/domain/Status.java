package com.lnk.marts.domain;

public enum Status {

	created,processing,pending,cancelled,declined,incomplete,complete;
}
